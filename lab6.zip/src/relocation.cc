#include "relocation.h"
#include <cstdint>
#include<iostream>
#include <sys/mman.h>
//#include<bits/stdc++.h>

void handleRela(std::vector<ObjectFile> &allObject, ObjectFile &mergedObject, bool isPIE)
{
    /* When there is more than 1 objects, 
     * you need to adjust the offset of each RelocEntry
     */
    /* Your code here */

    auto length=allObject.back().sections[".text"].off;
    length=0;
    for(auto& file:allObject){
        //length=length+file.sections[".text"].size;
        for(auto& relocentry:file.relocTable){
            relocentry.offset+=length;
        }
        length=length+file.sections[".text"].size;
    }




    /*
    uint64_t addr=0x555555555000;
    int valueToFill=42;
    *reinterpret_cast<int*>(addr)=valueToFill;
    */
    


    
    /* in PIE executables, user code starts at 0xe9 by .text section */
    /* in non-PIE executables, user code starts at 0xe6 by .text section */
    uint64_t userCodeStart = isPIE ? 0xe9 : 0xe6;
    uint64_t textOff = mergedObject.sections[".text"].off + userCodeStart;
    uint64_t textAddr = mergedObject.sections[".text"].addr + userCodeStart;

    /* Your code here */
    for(auto &file : allObject){
        for(auto &re : file.relocTable){
            uint64_t targetAddr=uint64_t(mergedObject.baseAddr)+re.offset+textOff;
            int valueToFill;
            if(re.type==R_X86_64_PC32||re.type==R_X86_64_PLT32){
                valueToFill=re.sym->value-(re.offset+textAddr)+re.addend;
            }
            else{
                valueToFill=re.sym->value+re.addend;
            }

            *reinterpret_cast<int*>(targetAddr)=valueToFill;







        //uint64_t targetAddr=re.offset+textAddr;
    

        //std::cout<<re.sym<<' '<<re.name<<std::endl;
        }
    }
}
