#include "resolve.h"
//#include<bits/stdc++.h>
#include <elf.h>
#include <iostream>
#include <regex>
#include<set>
#include<map>
//using namespace std;
#define FOUND_ALL_DEF 0
#define MULTI_DEF 1
#define NO_DEF 2

std::string errSymName;

int callResolveSymbols(std::vector<ObjectFile> &allObjects);

void resolveSymbols(std::vector<ObjectFile> &allObjects) {
    int ret = callResolveSymbols(allObjects);
    if (ret == MULTI_DEF) {
        std::cerr << "multiple definition for symbol " << errSymName << std::endl;
        abort();
    } else if (ret == NO_DEF) {
        std::cerr << "undefined reference for symbol " << errSymName << std::endl;
        abort();
    }
}

/* bind each undefined reference (reloc entry) to the exact valid symbol table entry
 * Throw correct errors when a reference is not bound to definition,
 * or there is more than one definition.
 */
int callResolveSymbols(std::vector<ObjectFile> &allObjects)
{
    /* Your code here */
    // if found multiple definition, set the errSymName to problematic symbol name and return MULTIDEF;
    // if no definition is found, set the errSymName to problematic symbol name and return NODEF;
    std::set<std::string> strong;
    strong.clear();
    std::map<std::string,Symbol*> strongname_sym;
    std::set<std::string> weak;
    std::map<std::string,Symbol*> weakname_sym;
    for(auto& f1:allObjects){
        for(auto& relocentry:f1.relocTable){
            int flag_strong=0;
            int flag_multi=0;
            int flag_weak=0;
            if(strong.find(relocentry.name)!=strong.end()){
                relocentry.sym=strongname_sym[relocentry.name];
            }
        
            for(auto& f2:allObjects){
                for(auto& symbol:f2.symbolTable){
                    if((symbol.name==relocentry.name)&&(symbol.bind==STB_GLOBAL)&&(symbol.index!=SHN_UNDEF)&&(symbol.index!=SHN_COMMON)){
                        if(flag_strong==0){
                            flag_strong=1;
                        }
                        else{
                            flag_multi=1;
                        }
                    }
                    if((symbol.name==relocentry.name)&&(symbol.bind==STB_GLOBAL)&&(symbol.index==SHN_COMMON)){
                        flag_weak=1;
                    }
                }
            }
            
            if(flag_strong==0&&flag_weak==0){
                errSymName=relocentry.name;
                return NO_DEF;
            }
            if(flag_strong==0&&flag_weak==1){
                if(strong.find(relocentry.name)!=strong.end()){
                    relocentry.sym=strongname_sym[relocentry.name];
                }
                else{
                    if(weak.find(relocentry.name)==weak.end()){
                        weak.insert(relocentry.name);
                        weakname_sym[relocentry.name]=relocentry.sym;
                    }
                    else{
                        relocentry.sym=weakname_sym[relocentry.name];
                    }
                }
            }
            if(flag_multi==1){
                errSymName=relocentry.name;
                return MULTI_DEF;
            }
            if(flag_strong==1){
                strong.insert(relocentry.name);
                strongname_sym[relocentry.name]=relocentry.sym;
            }
        }
    }


    return FOUND_ALL_DEF;
}
