#pragma once

#include "util.h"

void resolveSymbols(std::vector<ObjectFile> &allObjects);