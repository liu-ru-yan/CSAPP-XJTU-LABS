#include "poly.h"
#include<time.h>

void poly_optim(const double a[], double x, long degree, double *result) {
    // your code here
    /*
    long i;
    double r = a[degree];
    for (i = degree - 1; i >= 0; i--) {
        r = a[i] + r * x;
    }
    *result = r;
    */

    
    long i;
    double r1=a[degree];
    double r2=a[degree-1];
    double r3=a[degree-2];
    double r4=a[degree-3];
    double r5=a[degree-4];
    double r6=a[degree-5];
    double r7=a[degree-6];
    double r8=a[degree-7];
    double r9=a[degree-8];
    double r10=a[degree-9];
    double r11=a[degree-10];

    double X=x*x*x*x*x*x*x*x*x*x*x;
    for(i=degree-11;i>=0;i=i){
        if(i-10>=0){
            r1=r1*X+a[i];
            r2=r2*X+a[i-1];
            r3=r3*X+a[i-2];
            r4=r4*X+a[i-3];
            r5=r5*X+a[i-4];
            r6=r6*X+a[i-5];
            r7=r7*X+a[i-6];
            r8=r8*X+a[i-7];
            r9=r9*X+a[i-8];
            r10=r10*X+a[i-9];
            r11=r11*X+a[i-10];
            i=i-11;
        }
        else{
            break;
        }
    }

    r10=r10*x;
    r9=r9*x*x;
    r8=r8*x*x*x;
    r7=r7*x*x*x*x;
    r6=r6*x*x*x*x*x;
    r5=r5*x*x*x*x*x*x;
    r4=r4*x*x*x*x*x*x*x;
    r3=r3*x*x*x*x*x*x*x*x;
    r2=r2*x*x*x*x*x*x*x*x*x;
    r1=r1*x*x*x*x*x*x*x*x*x*x;


    double R=r1+r2+r3+r4+r5+r6+r7+r8+r9+r10+r11;


    long j=i;

    for(j=j;j>=0;j--){
        R=R*x+a[j];
    }
    *result=R;

    






    /*
    cpe6.24
    long i;
    double r1=a[degree];
    double r2=a[degree-1];
    double r3=a[degree-2];
    double r4=a[degree-3];
    double r5=a[degree-4];
    double r6=a[degree-5];
    double r7=a[degree-6];
    double r8=a[degree-7];
    double r9=a[degree-8];
    double r10=a[degree-9];

    
    for(i=degree-10;i>=0;i=i){
        if(i-9>=0){
            r1=r1*x*x*x*x*x*x*x*x*x*x+a[i];
            r2=r2*x*x*x*x*x*x*x*x*x*x+a[i-1];
            r3=r3*x*x*x*x*x*x*x*x*x*x+a[i-2];
            r4=r4*x*x*x*x*x*x*x*x*x*x+a[i-3];
            r5=r5*x*x*x*x*x*x*x*x*x*x+a[i-4];
            r6=r6*x*x*x*x*x*x*x*x*x*x+a[i-5];
            r7=r7*x*x*x*x*x*x*x*x*x*x+a[i-6];
            r8=r8*x*x*x*x*x*x*x*x*x*x+a[i-7];
            r9=r9*x*x*x*x*x*x*x*x*x*x+a[i-8];
            r10=r10*x*x*x*x*x*x*x*x*x*x+a[i-9];
            i=i-10;
        }
        else{
            break;
        }
    }

    r9=r9*x;
    r8=r8*x*x;
    r7=r7*x*x*x;
    r6=r6*x*x*x*x;
    r5=r5*x*x*x*x*x;
    r4=r4*x*x*x*x*x*x;
    r3=r3*x*x*x*x*x*x*x;
    r2=r2*x*x*x*x*x*x*x*x;
    r1=r1*x*x*x*x*x*x*x*x*x;


    double R=r1+r2+r3+r4+r5+r6+r7+r8+r9+r10;


    long j=i;

    for(j=j;j>=0;j--){
        R=R*x+a[j];
    }
    *result=R;
    */

    /*
      cpe5.92
    long i;
    double r1=a[degree];
    double r2=a[degree-1];
    double r3=a[degree-2];
    double r4=a[degree-3];
    double r5=a[degree-4];
    double r6=a[degree-5];
    double r7=a[degree-6];
    double r8=a[degree-7];
    double r9=a[degree-8];

    
    for(i=degree-9;i>=0;i=i){
        if(i-8>=0){
            r1=r1*x*x*x*x*x*x*x*x*x+a[i];
            r2=r2*x*x*x*x*x*x*x*x*x+a[i-1];
            r3=r3*x*x*x*x*x*x*x*x*x+a[i-2];
            r4=r4*x*x*x*x*x*x*x*x*x+a[i-3];
            r5=r5*x*x*x*x*x*x*x*x*x+a[i-4];
            r6=r6*x*x*x*x*x*x*x*x*x+a[i-5];
            r7=r7*x*x*x*x*x*x*x*x*x+a[i-6];
            r8=r8*x*x*x*x*x*x*x*x*x+a[i-7];
            r9=r9*x*x*x*x*x*x*x*x*x+a[i-8];
            i=i-9;
        }
        else{
            break;
        }
    }

    r8=r8*x;
    r7=r7*x*x;
    r6=r6*x*x*x;
    r5=r5*x*x*x*x;
    r4=r4*x*x*x*x*x;
    r3=r3*x*x*x*x*x*x;
    r2=r2*x*x*x*x*x*x*x;
    r1=r1*x*x*x*x*x*x*x*x;


    double R=r1+r2+r3+r4+r5+r6+r7+r8+r9;


    long j=i;

    for(j=j;j>=0;j--){
        R=R*x+a[j];
    }
    *result=R;
    */

    /*cpe5.64
    long i;
    double r1=a[degree];
    double r2=a[degree-1];
    double r3=a[degree-2];
    double r4=a[degree-3];
    double r5=a[degree-4];
    double r6=a[degree-5];
    double r7=a[degree-6];
    double r8=a[degree-7];

    
    for(i=degree-8;i>=0;i=i){
        if(i-7>=0){
            r1=r1*x*x*x*x*x*x*x*x+a[i];
            r2=r2*x*x*x*x*x*x*x*x+a[i-1];
            r3=r3*x*x*x*x*x*x*x*x+a[i-2];
            r4=r4*x*x*x*x*x*x*x*x+a[i-3];
            r5=r5*x*x*x*x*x*x*x*x+a[i-4];
            r6=r6*x*x*x*x*x*x*x*x+a[i-5];
            r7=r7*x*x*x*x*x*x*x*x+a[i-6];
            r8=r8*x*x*x*x*x*x*x*x+a[i-7];
            i=i-8;
        }
        else{
            break;
        }
    }


    r7=r7*x;
    r6=r6*x*x;
    r5=r5*x*x*x;
    r4=r4*x*x*x*x;
    r3=r3*x*x*x*x*x;
    r2=r2*x*x*x*x*x*x;
    r1=r1*x*x*x*x*x*x*x;


    double R=r1+r2+r3+r4+r5+r6+r7+r8;


    long j=i;

    for(j=j;j>=0;j--){
        R=R*x+a[j];
    }
    *result=R;
    */
    /*cpe5.63
    long i;
    double r1=a[degree];
    double r2=a[degree-1];
    double r3=a[degree-2];
    double r4=a[degree-3];
    double r5=a[degree-4];
    double r6=a[degree-5];
    double r7=a[degree-6];

    
    for(i=degree-7;i>=0;i=i){
        if(i-6>=0){
            r1=r1*x*x*x*x*x*x*x+a[i];
            r2=r2*x*x*x*x*x*x*x+a[i-1];
            r3=r3*x*x*x*x*x*x*x+a[i-2];
            r4=r4*x*x*x*x*x*x*x+a[i-3];
            r5=r5*x*x*x*x*x*x*x+a[i-4];
            r6=r6*x*x*x*x*x*x*x+a[i-5];
            r7=r7*x*x*x*x*x*x*x+a[i-6];
            i=i-7;
        }
        else{
            break;
        }
    }


    r6=r6*x;
    r5=r5*x*x;
    r4=r4*x*x*x;
    r3=r3*x*x*x*x;
    r2=r2*x*x*x*x*x;
    r1=r1*x*x*x*x*x*x;


    double R=r1+r2+r3+r4+r5+r6+r7;


    long j=i;

    for(j=j;j>=0;j--){
        R=R*x+a[j];
    }
    *result=R;
    */


    /*cpe5.69
    long i;
    double r1=a[degree];
    double r2=a[degree-1];
    double r3=a[degree-2];
    double r4=a[degree-3];
    double r5=a[degree-4];
    double r6=a[degree-5];

    
    for(i=degree-6;i>=0;i=i){
        if(i-5>=0){
            r1=r1*x*x*x*x*x*x+a[i];
            r2=r2*x*x*x*x*x*x+a[i-1];
            r3=r3*x*x*x*x*x*x+a[i-2];
            r4=r4*x*x*x*x*x*x+a[i-3];
            r5=r5*x*x*x*x*x*x+a[i-4];
            r6=r6*x*x*x*x*x*x+a[i-5];
            i=i-6;
        }
        else{
            break;
        }
    }


    r5=r5*x;
    r4=r4*x*x;
    r3=r3*x*x*x;
    r2=r2*x*x*x*x;
    r1=r1*x*x*x*x*x;


    double R=r1+r2+r3+r4+r5+r6;


    long j=i;

    for(j=j;j>=0;j--){
        R=R*x+a[j];
    }
    *result=R;
    */
    

    /*5.46
    long i;
    double r1=a[degree];
    double r2=a[degree-1];
    double r3=a[degree-2];
    double r4=a[degree-3];
    double r5=a[degree-4];

    
    for(i=degree-5;i>=0;i=i){
        if(i-4>=0){
            r1=r1*x*x*x*x*x+a[i];
            r2=r2*x*x*x*x*x+a[i-1];
            r3=r3*x*x*x*x*x+a[i-2];
            r4=r4*x*x*x*x*x+a[i-3];
            r5=r5*x*x*x*x*x+a[i-4];
            i=i-5;
        }
        else{
            break;
        }
    }


    r4=r4*x;
    r3=r3*x*x;
    r2=r2*x*x*x;
    r1=r1*x*x*x*x;


    double R=r1+r2+r3+r4+r5;


    long j=i;

    for(j=j;j>=0;j--){
        R=R*x+a[j];
    }
    *result=R;
    */


    /*5.55
    long i;
    double r1=a[degree];
    double r2=a[degree-1];
    double r3=a[degree-2];
    double r4=a[degree-3];

    
    for(i=degree-4;i>=0;i=i){
        if(i-3>=0){
            r1=r1*x*x*x*x+a[i];
            r2=r2*x*x*x*x+a[i-1];
            r3=r3*x*x*x*x+a[i-2];
            r4=r4*x*x*x*x+a[i-3];

            i=i-4;
        }
        else{
            break;
        }
    }


    r3=r3*x;
    r2=r2*x*x;
    r1=r1*x*x*x;


    double R=r1+r2+r3+r4;


    long j=i;

    for(j=j;j>=0;j--){
        R=R*x+a[j];
    }
    *result=R;
    */
    /*5.72
    long i;
    double r1=a[degree];
    double r2=a[degree-1];
    double r3=a[degree-2];

    
    for(i=degree-3;i>=0;i=i){
        if(i-2>=0){
            r1=r1*x*x*x+a[i];
            r2=r2*x*x*x+a[i-1];
            r3=r3*x*x*x+a[i-2];

            i=i-3;
        }
        else{
            break;
        }
    }


    r2=r2*x;
    r1=r1*x*x;


    double R=r1+r2+r3;


    long j=i;

    for(j=j;j>=0;j--){
        R=R*x+a[j];
    }
    *result=R;
    */












    /*
    long i;
    double r = a[degree];
    for (i = degree - 1; i >= 0; i=i) {
        if(i-20>=0){
            r = a[i] + r * x;
            r=a[i-1]+r*x;
            r=a[i-2]+r*x;
            r=a[i-3]+r*x;
            r=a[i-4]+r*x;
            r=a[i-5]+r*x;
            r=a[i-6]+r*x;
            r=a[i-7]+r*x;
            r=a[i-8]+r*x;
            r=a[i-9]+r*x;
            r=a[i-10]+r*x;
            r=a[i-11]+r*x;
            r=a[i-12]+r*x;
            r=a[i-13]+r*x;
            r=a[i-14]+r*x;
            r=a[i-15]+r*x;
            r=a[i-16]+r*x;
            r=a[i-17]+r*x;
            r=a[i-18]+r*x;
            r=a[i-19]+r*x;
            i=i-20;
        }
        else{
            break;
        }

    }
    for(i=i;i>=0;i--){
        r=a[i]+r*x;
    }
    *result = r;
    */












    /*
    long i;
    //double r=a[degree];
    long batch=degree/7;
    long batch_2=2*batch;
    long batch_3=3*batch;
    long batch_4=4*batch;
    long batch_5=5*batch;
    long batch_6=6*batch;
    double r7=a[degree],r6=a[batch_6],r5=a[batch_5],r4=a[batch_4],r3=a[batch_3],r2=a[batch_2],r1=a[batch];

    for(i=1;i<batch;i++){
        if(degree-i>batch_6){
            r7=a[degree-i]+r7*x;
        }
        if(batch_6-i>batch_5){
            r6=a[batch_6-i]+r6*x;
        }
        if(batch_5-i>batch_4){
            r5=a[batch_5-i]+r5*x;
        }
        if(batch_4-i>batch_3){
            r4=a[batch_4-i]+r4*x;
        }
        if(batch_3-i>batch_2){
            r3=a[batch_3-i]+r3*x;
        }
        if(batch_2-i>batch){
            r2=a[batch_2-i]+r2*x;
        }
        if(batch-i>0){
            r1=a[batch-i]+r1*x;
        }
    }
    long j=i;
    while(degree-j>batch_6){
        r7=a[degree-j]+r7*x;
        j++;
    }
    j=i;
    while(batch_6-j>batch_5){
        r6=a[batch_6-j]+r6*x;
        j++;
    }
    j=i;
    while(batch_5-j>batch_4){
        r5=a[batch_5-j]+r5*x;
        j++;
    }
    j=i;
    while(batch_4-j>batch_3){
        r4=a[batch_4-j]+r4*x;
        j++;
    }
    j=i;
    while(batch_3-j>batch_2){
        r3=a[batch_3-j]+r3*x;
        j++;
    }
    j=i;
    while(batch_2-j>batch){
        r2=a[batch_2-j]+r2*x;
        j++;
    }
    r1=r1+a[0];
    double r=r1+r2+r3+4+r5+r6+r7;
    *result=r;
    */

    /*
    long b=degree/2;
    double r1=a[degree],r2=a[b];
    long i;
    for(i=1;i<=b;i++){
        if(degree-i>b){
            r1=r1*x+a[degree-i];
        }
        if(b-i>0){
            r2=r2*x+a[b-i];
        }
    }
    long j=i;
    if()
    *result=r1+r2;
    */

    

    
   
}

void measure_time(poly_func_t poly, const double a[], double x, long degree,
                  double *time) {
    
    double c;
    int cycle=10;
    poly(a,x,degree,&c);
    clock_t start,end;
    double t,nt;
    start=clock();
    for(int i=0;i<cycle;i++){
        poly(a,x,degree,&c);
    }
    end=clock();
    t=(double)(end-start);
    t=(double)t/((double)cycle);
    nt=t*1e3;
    *time=nt;
    
    // your code here

    
}